"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Play, Wine, UtensilsCrossed, Mountain, TreePine } from "lucide-react";

const heroCategories = [
  {
    icon: Wine,
    label: "Vinos",
    sub: "Rutas del vino, bodegas y experiencias.",
    href: "/descubri/vinos",
  },
  {
    icon: UtensilsCrossed,
    label: "Gastronomía",
    sub: "Sabores que nacen de la tierra.",
    href: "/descubri/gastronomia",
  },
  {
    icon: Mountain,
    label: "Pueblos",
    sub: "Historia, cultura y tradiciones.",
    href: "/descubri/pueblos",
  },
  {
    icon: TreePine,
    label: "Naturaleza",
    sub: "Paisajes que enamoran. Aventura y relax.",
    href: "/descubri/naturaleza",
  },
];

export function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [videoReady, setVideoReady] = useState(false);

  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 600], [0, 180]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);

  return (
    <section
      ref={heroRef}
      className="relative h-screen min-h-[700px] flex flex-col overflow-hidden"
      aria-label="Bienvenida a La Rioja Turismo"
    >
      {/* Background image with parallax */}
      <motion.div className="absolute inset-0 z-0" style={{ y }}>
        <Image
          src="https://images.unsplash.com/photo-1506377585622-bedcbb027afc?w=1920&q=85&auto=format&fit=crop"
          alt="Viñedos al atardecer en La Rioja, Argentina"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
          style={{ animation: "kenBurns 20s ease-in-out infinite alternate" }}
        />

        {/* Overlay gradients */}
        <div className="absolute inset-0 hero-gradient" />
        <div className="absolute bottom-0 left-0 right-0 h-1/3 hero-gradient-bottom" />
      </motion.div>

      {/* Content */}
      <motion.div
        className="relative z-10 flex-1 flex flex-col justify-center"
        style={{ opacity }}
      >
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 w-full pt-20">
          <div className="max-w-3xl">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="flex items-center gap-3 mb-6"
            >
              <span className="gold-line" />
              <span className="section-label">Argentina · Región del vino</span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="text-white text-shadow-lg mb-6"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(3rem, 8vw, 7.5rem)",
                fontWeight: 800,
                lineHeight: "0.95",
                letterSpacing: "-0.03em",
              }}
            >
              LA RIOJA,
              <br />
              <em
                style={{
                  fontStyle: "italic",
                  color: "var(--color-light-gold)",
                }}
              >
                SABOR
              </em>{" "}
              DE VIDA
            </motion.h1>

            {/* Sub */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="text-white/75 text-lg mb-10 max-w-lg leading-relaxed text-shadow-sm"
              style={{ fontFamily: "var(--font-body)", fontWeight: 300 }}
            >
              Viñedos infinitos, pueblos con historia, gastronomía única y la calidez de su gente.
              Tu próxima gran experiencia te espera.
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.9 }}
              className="flex flex-wrap gap-4"
            >
              <Link href="/descubri" className="btn-primary">
                <span>Descubrí La Rioja</span>
                <ArrowRight size={15} />
              </Link>

              <button
                className="btn-outline text-white border-white/40 hover:border-rioja-gold hover:text-rioja-gold flex items-center gap-3 text-[11px] tracking-widest"
                aria-label="Ver video de La Rioja"
              >
                <span className="w-9 h-9 rounded-full border border-white/40 flex items-center justify-center flex-shrink-0">
                  <Play size={12} className="ml-0.5" fill="currentColor" />
                </span>
                <span>Ver Video</span>
              </button>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Category strip at bottom */}
      <div className="relative z-10">
        <div
          className="max-w-[1400px] mx-auto px-0 w-full"
          style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }}
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.1 }}
            className="grid grid-cols-2 lg:grid-cols-4"
          >
            {heroCategories.map((cat, i) => (
              <Link
                key={cat.label}
                href={cat.href}
                className="group flex items-start gap-4 p-5 lg:p-6 transition-all duration-300 hover:bg-white/5"
                style={{
                  borderRight: i < heroCategories.length - 1 ? "1px solid rgba(255,255,255,0.1)" : "none",
                }}
              >
                <cat.icon
                  size={20}
                  className="flex-shrink-0 mt-0.5 text-rioja-gold group-hover:scale-110 transition-transform duration-300"
                  aria-hidden="true"
                />
                <div>
                  <span
                    className="block text-white text-xs font-600 tracking-widest uppercase mb-1 group-hover:text-rioja-gold transition-colors"
                    style={{ fontFamily: "var(--font-body)", letterSpacing: "0.12em" }}
                  >
                    {cat.label}
                  </span>
                  <span
                    className="block text-white/45 text-[11px] leading-relaxed"
                    style={{ fontFamily: "var(--font-body)" }}
                  >
                    {cat.sub}
                  </span>
                </div>
              </Link>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-36 right-10 hidden lg:flex flex-col items-center gap-3 z-10"
        style={{ opacity: useTransform(scrollY, [0, 200], [1, 0]) }}
        aria-hidden="true"
      >
        <span
          className="text-white/30 text-[9px] tracking-[0.3em] uppercase rotate-90 origin-center"
          style={{ fontFamily: "var(--font-body)" }}
        >
          Scroll
        </span>
        <div className="w-px h-16 overflow-hidden">
          <motion.div
            className="w-full bg-rioja-gold"
            animate={{ y: ["-100%", "200%"] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
            style={{ height: "50%" }}
          />
        </div>
      </motion.div>
    </section>
  );
}
