"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, MapPin } from "lucide-react";

const routes = [
  {
    id: "chilecito",
    name: "Chilecito",
    x: 28,
    y: 18,
    description: "Capital vitivinícola. Bodegas centenarias y paisajes de montaña únicos.",
  },
  {
    id: "famatina",
    name: "Valle del Famatina",
    x: 34,
    y: 42,
    description: "El valle de los viñedos de altura. Vinos de gran carácter.",
  },
  {
    id: "calchaquies",
    name: "Valles Calchaquíes",
    x: 60,
    y: 55,
    description: "Paisajes imponentes con tradiciones milenarias.",
  },
  {
    id: "costa",
    name: "Costa Riojana",
    x: 86,
    y: 68,
    description: "Orillas del embalse. Pesca, deportes acuáticos y descanso.",
  },
];

export function WineRoutesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section
      className="relative py-24 lg:py-32 overflow-hidden"
      style={{ background: "var(--color-dark-earth)" }}
      aria-labelledby="routes-title"
    >
      {/* Background image with overlay */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1559628129-67cf63b72248?w=1920&q=70&auto=format&fit=crop"
          alt="Viñedos de La Rioja desde el aire"
          fill
          sizes="100vw"
          className="object-cover opacity-25"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(135deg, rgba(26,15,8,0.96) 0%, rgba(74,15,28,0.85) 50%, rgba(26,15,8,0.96) 100%)",
          }}
        />
      </div>

      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center" ref={ref}>
          {/* Left: Content */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            >
              <span className="section-label mb-4 block">Rutas del Vino</span>
              <h2
                id="routes-title"
                className="text-white mb-6"
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "clamp(2.5rem, 4vw, 3.8rem)",
                  fontWeight: 800,
                  lineHeight: "1",
                }}
              >
                CAMINOS
                <br />
                <em style={{ fontStyle: "italic", color: "var(--color-light-gold)" }}>
                  QUE INSPIRAN
                </em>
              </h2>
              <p
                className="text-white/60 leading-relaxed mb-10 max-w-md"
                style={{ fontFamily: "var(--font-body)", fontSize: "1rem" }}
              >
                Recorré nuestras rutas del vino y descubrí bodegas únicas, pueblos encantadores y
                paisajes que te van a sorprender.
              </p>

              <Link
                href="/rutas"
                className="inline-flex items-center gap-2 text-sm font-semibold tracking-widest uppercase link-underline"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "var(--color-gold)",
                  letterSpacing: "0.12em",
                }}
              >
                Descubrir Rutas
                <ArrowRight size={14} />
              </Link>
            </motion.div>

            {/* Route list */}
            <motion.div
              className="mt-12 space-y-0"
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              {routes.map((route, i) => (
                <motion.div
                  key={route.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.4 + i * 0.1 }}
                  className="group flex items-start gap-4 py-4 border-b border-white/8 cursor-pointer hover:border-rioja-gold/30 transition-colors"
                >
                  <span
                    className="text-rioja-gold font-700 text-xs mt-1 flex-shrink-0"
                    style={{ fontFamily: "var(--font-accent)" }}
                    aria-hidden="true"
                  >
                    0{i + 1}
                  </span>
                  <div>
                    <h3
                      className="text-white font-600 mb-1 group-hover:text-rioja-gold transition-colors"
                      style={{ fontFamily: "var(--font-display)", fontSize: "1rem" }}
                    >
                      {route.name}
                    </h3>
                    <p
                      className="text-white/45 text-[13px] leading-relaxed"
                      style={{ fontFamily: "var(--font-body)" }}
                    >
                      {route.description}
                    </p>
                  </div>
                  <ArrowRight
                    size={14}
                    className="ml-auto flex-shrink-0 text-white/20 group-hover:text-rioja-gold group-hover:translate-x-1 transition-all duration-300 mt-1"
                  />
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Right: Map */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <div
              className="relative aspect-[4/5] w-full max-w-md mx-auto lg:mx-0 lg:ml-auto"
              style={{
                border: "1px solid rgba(196,149,42,0.2)",
                background: "rgba(196,149,42,0.03)",
              }}
            >
              {/* Map label */}
              <div className="absolute top-6 right-6 text-right z-10">
                <span
                  className="block text-rioja-gold text-[9px] tracking-[0.3em] uppercase"
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  LA RIOJA
                </span>
                <span
                  className="block text-white/40 text-[9px] tracking-[0.2em] uppercase"
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  ARGENTINA
                </span>
              </div>

              {/* SVG Map */}
              <svg
                viewBox="0 0 400 500"
                className="w-full h-full"
                aria-label="Mapa de rutas del vino en La Rioja"
                role="img"
              >
                {/* Province outline - simplified La Rioja shape */}
                <path
                  d="M 120 40 L 280 30 L 340 80 L 360 160 L 340 260 L 320 340 L 290 400 L 240 460 L 180 450 L 120 380 L 80 300 L 60 200 L 80 120 Z"
                  fill="none"
                  stroke="rgba(196,149,42,0.25)"
                  strokeWidth="1.5"
                />
                <path
                  d="M 120 40 L 280 30 L 340 80 L 360 160 L 340 260 L 320 340 L 290 400 L 240 460 L 180 450 L 120 380 L 80 300 L 60 200 L 80 120 Z"
                  fill="rgba(196,149,42,0.04)"
                />

                {/* Animated route path */}
                <path
                  d="M 148 110 Q 160 190 176 220 Q 200 260 252 280 Q 290 300 314 352"
                  fill="none"
                  stroke="rgba(196,149,42,0.5)"
                  strokeWidth="1.5"
                  strokeDasharray="5 4"
                  className="route-path"
                />

                {/* Route dots */}
                {routes.map((route, i) => (
                  <g key={route.id}>
                    <circle
                      cx={route.x * 4}
                      cy={route.y * 5}
                      r="5"
                      fill="var(--color-gold)"
                      opacity="0.9"
                    />
                    <circle
                      cx={route.x * 4}
                      cy={route.y * 5}
                      r="12"
                      fill="var(--color-gold)"
                      opacity="0.15"
                    />
                    <text
                      x={route.x * 4 + 16}
                      y={route.y * 5 + 4}
                      fill="rgba(255,255,255,0.7)"
                      fontSize="9"
                      fontFamily="Jost, sans-serif"
                      letterSpacing="0.05em"
                    >
                      {route.name}
                    </text>
                  </g>
                ))}

                {/* Decorative elements */}
                <text
                  x="30"
                  y="480"
                  fill="rgba(196,149,42,0.2)"
                  fontSize="7"
                  fontFamily="Jost, sans-serif"
                  letterSpacing="0.2em"
                >
                  RUTAS DEL VINO
                </text>
              </svg>

              {/* Corner decoration */}
              <div
                className="absolute bottom-4 left-4 flex items-center gap-3"
                aria-hidden="true"
              >
                <div className="w-8 h-px" style={{ background: "var(--color-gold)" }} />
                <MapPin size={12} className="text-rioja-gold" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
