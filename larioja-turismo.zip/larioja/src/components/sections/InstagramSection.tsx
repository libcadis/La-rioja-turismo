"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { Instagram, ArrowRight } from "lucide-react";

const instagramPosts = [
  {
    id: "1",
    src: "https://images.unsplash.com/photo-1506377585622-bedcbb027afc?w=600&q=80&auto=format&fit=crop",
    alt: "Viñedos en La Rioja al atardecer",
  },
  {
    id: "2",
    src: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600&q=80&auto=format&fit=crop",
    alt: "Gastronomía riojana",
  },
  {
    id: "3",
    src: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80&auto=format&fit=crop",
    alt: "Montañas de La Rioja",
  },
  {
    id: "4",
    src: "https://images.unsplash.com/photo-1490131784822-b4626a8ec96a?w=600&q=80&auto=format&fit=crop",
    alt: "Caminata en los valles riojanos",
  },
  {
    id: "5",
    src: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80&auto=format&fit=crop",
    alt: "Paisaje natural La Rioja",
  },
];

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.08 } },
};

const cellVariants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
};

export function InstagramSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section
      className="py-24 lg:py-32 overflow-hidden"
      style={{ background: "var(--color-dark-earth)" }}
      aria-labelledby="instagram-title"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-8 mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <Instagram size={16} className="text-rioja-gold" aria-hidden="true" />
              <span className="section-label">#LaRiojaTurismo</span>
            </div>
            <h2
              id="instagram-title"
              className="text-white"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2rem, 4vw, 3rem)",
                fontWeight: 800,
                lineHeight: "1",
              }}
            >
              INSPIRATE
            </h2>
            <p
              className="text-white/50 mt-3 max-w-xs"
              style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem" }}
            >
              Compartí tu experiencia y etiquetanos.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="flex items-center gap-4 mb-6">
              <a
                href="https://instagram.com/lariojaturismo"
                className="text-white/40 hover:text-rioja-gold transition-colors"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram de La Rioja Turismo"
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>
              <a
                href="https://facebook.com/lariojaturismo"
                className="text-white/40 hover:text-rioja-gold transition-colors"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook de La Rioja Turismo"
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>
              <a
                href="https://youtube.com/lariojaturismo"
                className="text-white/40 hover:text-rioja-gold transition-colors"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube de La Rioja Turismo"
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z" />
                </svg>
              </a>
            </div>
          </motion.div>
        </div>

        {/* Photo grid */}
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-2 md:grid-cols-5 gap-2"
          role="list"
          aria-label="Galería de fotos de La Rioja"
        >
          {instagramPosts.map((post) => (
            <motion.a
              key={post.id}
              variants={cellVariants}
              href="https://instagram.com/lariojaturismo"
              target="_blank"
              rel="noopener noreferrer"
              className="ig-item relative aspect-square overflow-hidden block"
              aria-label={`Ver foto en Instagram: ${post.alt}`}
              role="listitem"
            >
              <Image
                src={post.src}
                alt={post.alt}
                fill
                sizes="(max-width: 768px) 50vw, 20vw"
                className="object-cover"
              />
              {/* Hover overlay */}
              <div className="ig-overlay absolute inset-0 flex items-center justify-center" style={{ background: "rgba(74,15,28,0.6)" }}>
                <Instagram size={24} className="text-white" aria-hidden="true" />
              </div>
            </motion.a>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-center mt-10"
        >
          <a
            href="https://instagram.com/lariojaturismo"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 text-[11px] tracking-widest uppercase font-600 text-white transition-all duration-300 hover:bg-white/10"
            style={{
              fontFamily: "var(--font-body)",
              border: "1px solid rgba(255,255,255,0.2)",
              letterSpacing: "0.15em",
            }}
          >
            <Instagram size={14} aria-hidden="true" />
            <span>Ver Más en Instagram</span>
            <ArrowRight size={12} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
