"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight } from "lucide-react";

const experiences = [
  {
    id: "enoturismo",
    category: "Enoturismo",
    title: "Vive el vino desde su origen.",
    description:
      "Bodegas, catas y paisajes inolvidables. Recorré las rutas del vino riojanas y descubrí la magia de cada copa.",
    image:
      "https://images.unsplash.com/photo-1543362906-acfc16c67564?w=800&q=80&auto=format&fit=crop",
    alt: "Copa de vino tinto riojano con viñedos al atardecer",
    href: "/que-hacer/enoturismo",
    accent: "#8B2035",
  },
  {
    id: "gastronomia",
    category: "Gastronomía",
    title: "Productos locales, recetas que celebran la tierra.",
    description:
      "Chefs tradicionales y cocina de raíz riojana. Una experiencia culinaria que despertará todos tus sentidos.",
    image:
      "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80&auto=format&fit=crop",
    alt: "Plato gourmet con ingredientes riojanos",
    href: "/descubri/gastronomia",
    accent: "#C4952A",
  },
  {
    id: "naturaleza",
    category: "Naturaleza",
    title: "Montañas, ríos y cielos despejados.",
    description:
      "Conectate con lo esencial en paisajes únicos de los valles, sierras y cielos estrellados de La Rioja.",
    image:
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80&auto=format&fit=crop",
    alt: "Paisaje montañoso en La Rioja Argentina",
    href: "/descubri/naturaleza",
    accent: "#3D6B45",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1] },
  },
};

export function ExperiencesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section
      className="py-24 lg:py-32"
      style={{ background: "var(--color-light-cream)" }}
      aria-labelledby="experiences-title"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 mb-16 items-end">
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
              viewport={{ once: true }}
            >
              <span className="section-label mb-4 block">Experiencias que enamoran</span>
              <h2
                id="experiences-title"
                className="text-rioja-earth"
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "clamp(2.5rem, 4vw, 3.5rem)",
                  lineHeight: "1",
                  fontWeight: 800,
                }}
              >
                VIVE LA RIOJA
                <br />
                <em
                  style={{
                    fontStyle: "italic",
                    color: "var(--color-burgundy)",
                  }}
                >
                  A TU MANERA
                </em>
              </h2>
            </motion.div>
          </div>

          <motion.div
            className="lg:col-span-1"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            viewport={{ once: true }}
          >
            <p
              className="text-rioja-stone leading-relaxed"
              style={{ fontFamily: "var(--font-body)", fontSize: "1rem" }}
            >
              Experiencias auténticas para disfrutar de nuestros viñedos, sabores, paisajes y cultura.
            </p>
          </motion.div>

          <motion.div
            className="lg:col-span-1 lg:text-right"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            viewport={{ once: true }}
          >
            <Link
              href="/experiencias"
              className="inline-flex items-center gap-2 text-sm font-semibold tracking-widest uppercase link-underline"
              style={{
                fontFamily: "var(--font-body)",
                color: "var(--color-burgundy)",
                letterSpacing: "0.12em",
              }}
            >
              Explorar Experiencias
              <ArrowRight size={14} />
            </Link>
          </motion.div>
        </div>

        {/* Cards grid */}
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {experiences.map((exp) => (
            <motion.div
              key={exp.id}
              variants={cardVariants}
              className="exp-card group relative overflow-hidden cursor-pointer"
              style={{ background: "var(--color-dark-earth)" }}
            >
              {/* Image */}
              <div className="relative h-72 overflow-hidden">
                <Image
                  src={exp.image}
                  alt={exp.alt}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.06]"
                />

                {/* Category badge */}
                <div className="absolute top-5 left-5 z-10">
                  <span
                    className="text-[9px] font-600 tracking-[0.2em] uppercase px-3 py-1.5 text-white"
                    style={{
                      background: exp.accent,
                      fontFamily: "var(--font-body)",
                    }}
                  >
                    {exp.category}
                  </span>
                </div>

                {/* Overlay on hover */}
                <div
                  className="exp-card-overlay absolute inset-0 flex items-end justify-center pb-6 z-10"
                  style={{
                    background: `linear-gradient(to top, ${exp.accent}cc, transparent)`,
                  }}
                >
                  <Link
                    href={exp.href}
                    className="inline-flex items-center gap-2 text-white text-[10px] tracking-widest uppercase font-600 border border-white/50 px-5 py-2.5 hover:bg-white hover:text-rioja-earth transition-all duration-300"
                    style={{ fontFamily: "var(--font-body)", letterSpacing: "0.14em" }}
                    aria-label={`Ver más sobre ${exp.category}`}
                  >
                    Ver Más
                    <ArrowRight size={12} />
                  </Link>
                </div>
              </div>

              {/* Content */}
              <div className="p-7">
                <h3
                  className="text-white font-700 mb-3 leading-snug"
                  style={{
                    fontFamily: "var(--font-display)",
                    fontSize: "1.2rem",
                    fontWeight: 700,
                  }}
                >
                  {exp.title}
                </h3>
                <p
                  className="text-white/55 text-sm leading-relaxed mb-5"
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  {exp.description}
                </p>
                <Link
                  href={exp.href}
                  className="inline-flex items-center gap-2 text-[10px] tracking-widest uppercase transition-colors duration-200 hover:gap-3"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-gold)",
                    letterSpacing: "0.14em",
                  }}
                >
                  Ver Más
                  <ArrowRight size={11} />
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
