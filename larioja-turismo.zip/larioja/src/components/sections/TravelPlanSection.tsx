"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import Link from "next/link";
import { ArrowRight, BedDouble, CalendarDays, MapIcon, Info } from "lucide-react";

const planCards = [
  {
    icon: BedDouble,
    label: "Dónde Dormir",
    description: "Hoteles, cabañas y alojamientos para todos los gustos.",
    link: "Ver Opciones",
    href: "/planifica/alojamiento",
  },
  {
    icon: CalendarDays,
    label: "Eventos",
    description: "No te pierdas lo que pasa todo el año en La Rioja.",
    link: "Ver Calendario",
    href: "/planifica/eventos",
  },
  {
    icon: MapIcon,
    label: "Cómo Llegar",
    description: "Rutas, accesos y toda la info para llegar sin dudas.",
    link: "Ver Mapa",
    href: "/planifica/como-llegar",
  },
  {
    icon: Info,
    label: "Oficinas de Turismo",
    description: "Estamos para ayudarte antes y durante tu viaje.",
    link: "Ver Contactos",
    href: "/info/oficinas",
  },
];

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};

const item = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
};

export function TravelPlanSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section
      className="py-24 lg:py-32"
      style={{ background: "var(--color-light-cream)" }}
      aria-labelledby="plan-title"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-16 items-end">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="section-label mb-4 block">Planificá tu Viaje</span>
            <h2
              id="plan-title"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2rem, 4vw, 3.2rem)",
                fontWeight: 800,
                lineHeight: "1",
                color: "var(--color-earth)",
              }}
            >
              TODO LO QUE NECESITÁS
              <br />
              <em style={{ fontStyle: "italic", color: "var(--color-burgundy)" }}>
                PARA TU ESCAPADA
              </em>
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.15 }}
          >
            <p
              className="text-rioja-stone leading-relaxed max-w-md"
              style={{ fontFamily: "var(--font-body)", fontSize: "1rem" }}
            >
              Organizá tu viaje fácil y rápido. Encontrá alojamientos, eventos, mapas y tips para disfrutar al máximo.
            </p>
          </motion.div>
        </div>

        {/* Cards */}
        <motion.div
          ref={ref}
          variants={stagger}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0"
          style={{ border: "1px solid rgba(61,43,31,0.1)" }}
        >
          {planCards.map((card, i) => (
            <motion.div
              key={card.label}
              variants={item}
              className="group p-8 lg:p-10 cursor-pointer transition-all duration-300 hover:bg-rioja-burgundy/5"
              style={{
                borderRight: i < planCards.length - 1 ? "1px solid rgba(61,43,31,0.1)" : "none",
              }}
            >
              <card.icon
                size={24}
                className="mb-5 transition-transform duration-300 group-hover:scale-110"
                style={{ color: "var(--color-burgundy)" }}
                aria-hidden="true"
              />
              <h3
                className="font-700 mb-2"
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "1.1rem",
                  color: "var(--color-earth)",
                }}
              >
                {card.label}
              </h3>
              <p
                className="text-rioja-stone text-sm leading-relaxed mb-6"
                style={{ fontFamily: "var(--font-body)" }}
              >
                {card.description}
              </p>
              <Link
                href={card.href}
                className="inline-flex items-center gap-2 text-[10px] tracking-widest uppercase font-600 link-underline transition-colors duration-200 group-hover:gap-3"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "var(--color-burgundy)",
                  letterSpacing: "0.14em",
                }}
                aria-label={`${card.link} - ${card.label}`}
              >
                {card.link}
                <ArrowRight size={11} />
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
