"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Search, ChevronDown, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  {
    label: "Descubrí La Rioja",
    href: "/descubri",
    children: [
      { label: "Historia y Cultura", href: "/descubri/historia" },
      { label: "Naturaleza", href: "/descubri/naturaleza" },
      { label: "Pueblos", href: "/descubri/pueblos" },
      { label: "Gastronomía", href: "/descubri/gastronomia" },
    ],
  },
  {
    label: "Qué Hacer",
    href: "/que-hacer",
    children: [
      { label: "Enoturismo", href: "/que-hacer/enoturismo" },
      { label: "Aventura", href: "/que-hacer/aventura" },
      { label: "Cultura", href: "/que-hacer/cultura" },
      { label: "Relax", href: "/que-hacer/relax" },
    ],
  },
  {
    label: "Dónde Ir",
    href: "/donde-ir",
    children: [
      { label: "Chilecito", href: "/donde-ir/chilecito" },
      { label: "Valles Calchaquíes", href: "/donde-ir/valles-calchaquies" },
      { label: "Costa Riojana", href: "/donde-ir/costa-riojana" },
      { label: "Valle del Famatina", href: "/donde-ir/famatina" },
    ],
  },
  {
    label: "Planificá tu Viaje",
    href: "/planifica",
    children: [
      { label: "Dónde Dormir", href: "/planifica/alojamiento" },
      { label: "Cómo Llegar", href: "/planifica/como-llegar" },
      { label: "Eventos", href: "/planifica/eventos" },
      { label: "Mapa", href: "/planifica/mapa" },
    ],
  },
  {
    label: "Eventos",
    href: "/eventos",
  },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setActiveDropdown(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <>
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
          scrolled ? "nav-solid" : "nav-transparent"
        )}
        role="banner"
      >
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link
              href="/"
              className="flex items-center gap-3 flex-shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rioja-gold"
              aria-label="La Rioja Turismo - Inicio"
            >
              <div className="flex flex-col items-start">
                <span
                  className="text-xl font-bold tracking-wider text-white"
                  style={{ fontFamily: "var(--font-display)", letterSpacing: "0.06em" }}
                >
                  LA RIOJA
                </span>
                <span
                  className="text-[9px] tracking-[0.3em] uppercase text-rioja-gold -mt-0.5"
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  TURISMO
                </span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav
              ref={dropdownRef}
              className="hidden lg:flex items-center gap-1"
              aria-label="Navegación principal"
            >
              {navItems.map((item) => (
                <div key={item.label} className="relative">
                  {item.children ? (
                    <button
                      className={cn(
                        "flex items-center gap-1 px-4 py-2 text-[11px] font-500 tracking-widest uppercase transition-colors duration-200",
                        "text-white/85 hover:text-rioja-gold focus-visible:text-rioja-gold",
                        activeDropdown === item.label && "text-rioja-gold"
                      )}
                      style={{ fontFamily: "var(--font-body)", letterSpacing: "0.12em" }}
                      onClick={() =>
                        setActiveDropdown(activeDropdown === item.label ? null : item.label)
                      }
                      aria-expanded={activeDropdown === item.label}
                      aria-haspopup="true"
                    >
                      {item.label}
                      <ChevronDown
                        size={12}
                        className={cn(
                          "transition-transform duration-200",
                          activeDropdown === item.label && "rotate-180"
                        )}
                      />
                    </button>
                  ) : (
                    <Link
                      href={item.href}
                      className="flex items-center px-4 py-2 text-[11px] font-500 tracking-widest uppercase text-white/85 hover:text-rioja-gold transition-colors duration-200"
                      style={{ fontFamily: "var(--font-body)", letterSpacing: "0.12em" }}
                    >
                      {item.label}
                    </Link>
                  )}

                  <AnimatePresence>
                    {item.children && activeDropdown === item.label && (
                      <motion.div
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 8 }}
                        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                        className="absolute top-full left-0 mt-1 min-w-[200px] py-2"
                        style={{
                          background: "rgba(26, 15, 8, 0.97)",
                          border: "1px solid rgba(196, 149, 42, 0.2)",
                          backdropFilter: "blur(20px)",
                        }}
                        role="menu"
                      >
                        {item.children.map((child) => (
                          <Link
                            key={child.label}
                            href={child.href}
                            className="block px-5 py-2.5 text-[11px] tracking-widest uppercase text-white/70 hover:text-rioja-gold hover:bg-white/5 transition-all duration-200"
                            style={{ fontFamily: "var(--font-body)", letterSpacing: "0.12em" }}
                            role="menuitem"
                            onClick={() => setActiveDropdown(null)}
                          >
                            {child.label}
                          </Link>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </nav>

            {/* Right actions */}
            <div className="flex items-center gap-3">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2 text-white/70 hover:text-rioja-gold transition-colors duration-200 focus-visible:outline-none"
                aria-label="Buscar"
              >
                <Search size={18} />
              </button>

              {/* Language */}
              <button
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-[10px] tracking-widest uppercase text-white/70 hover:text-rioja-gold transition-colors duration-200"
                style={{ fontFamily: "var(--font-body)" }}
                aria-label="Cambiar idioma"
              >
                <Globe size={13} />
                ES
              </button>

              {/* CTA */}
              <Link
                href="/reservar"
                className="hidden lg:inline-flex btn-primary text-[10px]"
                aria-label="Reservar experiencia ahora"
              >
                <span>Reservá Ahora</span>
              </Link>

              {/* Mobile menu toggle */}
              <button
                className="lg:hidden p-2 text-white focus-visible:outline-none"
                onClick={() => setMobileOpen(true)}
                aria-label="Abrir menú"
                aria-expanded={mobileOpen}
              >
                <Menu size={22} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[60] bg-black/60"
              onClick={() => setMobileOpen(false)}
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="fixed right-0 top-0 bottom-0 z-[70] w-[320px] flex flex-col"
              style={{
                background: "var(--color-dark-earth)",
                borderLeft: "1px solid rgba(196, 149, 42, 0.2)",
              }}
              role="dialog"
              aria-modal="true"
              aria-label="Menú de navegación"
            >
              <div className="flex items-center justify-between p-6 border-b border-rioja-gold/20">
                <div className="flex flex-col">
                  <span
                    className="text-lg font-bold tracking-wider text-white"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    LA RIOJA
                  </span>
                  <span className="text-[8px] tracking-[0.3em] uppercase text-rioja-gold">
                    TURISMO
                  </span>
                </div>
                <button
                  onClick={() => setMobileOpen(false)}
                  className="p-2 text-white/70 hover:text-white transition-colors"
                  aria-label="Cerrar menú"
                >
                  <X size={20} />
                </button>
              </div>

              <nav className="flex-1 overflow-y-auto py-6" aria-label="Navegación móvil">
                {navItems.map((item, i) => (
                  <MobileNavItem
                    key={item.label}
                    item={item}
                    delay={i * 0.05}
                    onClose={() => setMobileOpen(false)}
                  />
                ))}
              </nav>

              <div className="p-6 border-t border-rioja-gold/20">
                <Link
                  href="/reservar"
                  className="btn-primary w-full justify-center text-[11px]"
                  onClick={() => setMobileOpen(false)}
                >
                  <span>Reservá Tu Experiencia</span>
                </Link>
                <div className="flex items-center gap-4 mt-4 justify-center">
                  <a href="https://instagram.com/lariojaturismo" className="text-white/50 hover:text-rioja-gold transition-colors" aria-label="Instagram">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                    </svg>
                  </a>
                  <a href="https://facebook.com/lariojaturismo" className="text-white/50 hover:text-rioja-gold transition-colors" aria-label="Facebook">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                  </a>
                  <a href="https://youtube.com/lariojaturismo" className="text-white/50 hover:text-rioja-gold transition-colors" aria-label="YouTube">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/>
                    </svg>
                  </a>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Search Modal */}
      <AnimatePresence>
        {searchOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[80] bg-black/80 bg-blur"
              onClick={() => setSearchOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="fixed top-24 left-1/2 -translate-x-1/2 z-[90] w-full max-w-2xl px-6"
              role="dialog"
              aria-modal="true"
              aria-label="Buscar"
            >
              <div
                className="relative flex items-center"
                style={{
                  background: "rgba(26, 15, 8, 0.97)",
                  border: "1px solid rgba(196, 149, 42, 0.3)",
                }}
              >
                <Search size={18} className="absolute left-5 text-rioja-gold" />
                <input
                  type="search"
                  placeholder="Buscá destinos, experiencias, actividades..."
                  className="w-full bg-transparent pl-14 pr-14 py-5 text-white text-sm placeholder-white/40 focus:outline-none"
                  style={{ fontFamily: "var(--font-body)" }}
                  autoFocus
                />
                <button
                  onClick={() => setSearchOpen(false)}
                  className="absolute right-5 text-white/40 hover:text-white transition-colors"
                  aria-label="Cerrar búsqueda"
                >
                  <X size={18} />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

function MobileNavItem({
  item,
  delay,
  onClose,
}: {
  item: typeof navItems[0];
  delay: number;
  onClose: () => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay, duration: 0.3 }}
    >
      {item.children ? (
        <>
          <button
            className="flex items-center justify-between w-full px-6 py-3.5 text-[11px] tracking-widest uppercase text-white/70 hover:text-rioja-gold transition-colors"
            style={{ fontFamily: "var(--font-body)" }}
            onClick={() => setOpen(!open)}
            aria-expanded={open}
          >
            {item.label}
            <ChevronDown
              size={12}
              className={cn("transition-transform duration-200", open && "rotate-180")}
            />
          </button>
          <AnimatePresence>
            {open && (
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: "auto" }}
                exit={{ height: 0 }}
                className="overflow-hidden"
                style={{ background: "rgba(255,255,255,0.04)" }}
              >
                {item.children.map((child) => (
                  <Link
                    key={child.label}
                    href={child.href}
                    className="block px-10 py-2.5 text-[10px] tracking-widest uppercase text-white/50 hover:text-rioja-gold transition-colors"
                    style={{ fontFamily: "var(--font-body)" }}
                    onClick={onClose}
                  >
                    {child.label}
                  </Link>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </>
      ) : (
        <Link
          href={item.href}
          className="flex items-center px-6 py-3.5 text-[11px] tracking-widest uppercase text-white/70 hover:text-rioja-gold transition-colors"
          style={{ fontFamily: "var(--font-body)" }}
          onClick={onClose}
        >
          {item.label}
        </Link>
      )}
    </motion.div>
  );
}
