import Link from "next/link";

const footerSections = [
  {
    title: "Descubrí",
    links: [
      { label: "Vinos", href: "/descubri/vinos" },
      { label: "Gastronomía", href: "/descubri/gastronomia" },
      { label: "Pueblos", href: "/descubri/pueblos" },
      { label: "Naturaleza", href: "/descubri/naturaleza" },
    ],
  },
  {
    title: "Información",
    links: [
      { label: "Planificá tu viaje", href: "/planifica" },
      { label: "Cómo llegar", href: "/planifica/como-llegar" },
      { label: "Preguntas frecuentes", href: "/info/faq" },
      { label: "Oficinas de turismo", href: "/info/oficinas" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Términos y condiciones", href: "/legal/terminos" },
      { label: "Privacidad", href: "/legal/privacidad" },
      { label: "Transparencia", href: "/legal/transparencia" },
    ],
  },
];

export function Footer() {
  return (
    <footer
      className="relative"
      style={{ background: "var(--color-dark-earth)" }}
      role="contentinfo"
    >
      {/* Gold divider */}
      <div className="divider-gold opacity-30" />

      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Main footer grid */}
        <div className="py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="inline-block mb-6" aria-label="La Rioja Turismo">
              <div className="flex flex-col">
                <span
                  className="text-2xl font-bold tracking-wider text-white"
                  style={{ fontFamily: "var(--font-display)", letterSpacing: "0.06em" }}
                >
                  LA RIOJA
                </span>
                <span
                  className="text-[9px] tracking-[0.3em] uppercase text-rioja-gold"
                  style={{ fontFamily: "var(--font-body)" }}
                >
                  TURISMO
                </span>
              </div>
            </Link>

            <p
              className="text-white/50 text-sm leading-relaxed mb-8 max-w-xs"
              style={{ fontFamily: "var(--font-body)" }}
            >
              Auténtica por naturaleza. Viñedos infinitos, pueblos con historia y gastronomía que nace de la tierra.
            </p>

            {/* Social links */}
            <div className="flex items-center gap-4 mb-8">
              <a
                href="https://instagram.com/lariojaturismo"
                className="w-9 h-9 flex items-center justify-center text-white/50 hover:text-rioja-gold transition-colors border border-white/10 hover:border-rioja-gold/40"
                aria-label="Seguinos en Instagram"
                target="_blank"
                rel="noopener noreferrer"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>
              <a
                href="https://facebook.com/lariojaturismo"
                className="w-9 h-9 flex items-center justify-center text-white/50 hover:text-rioja-gold transition-colors border border-white/10 hover:border-rioja-gold/40"
                aria-label="Seguinos en Facebook"
                target="_blank"
                rel="noopener noreferrer"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>
              <a
                href="https://youtube.com/lariojaturismo"
                className="w-9 h-9 flex items-center justify-center text-white/50 hover:text-rioja-gold transition-colors border border-white/10 hover:border-rioja-gold/40"
                aria-label="Suscribite en YouTube"
                target="_blank"
                rel="noopener noreferrer"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Links */}
          {footerSections.map((section) => (
            <div key={section.title}>
              <h3
                className="section-label mb-5"
                style={{ fontFamily: "var(--font-body)" }}
              >
                {section.title}
              </h3>
              <ul className="space-y-2.5">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-white/50 hover:text-rioja-gold text-sm transition-colors duration-200 link-underline"
                      style={{ fontFamily: "var(--font-body)" }}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Newsletter */}
          <div className="lg:col-span-1 md:col-span-2">
            <h3 className="section-label mb-2">Suscribite al Newsletter</h3>
            <p
              className="text-white/40 text-xs mb-4 leading-relaxed"
              style={{ fontFamily: "var(--font-body)" }}
            >
              Recibí novedades y promociones exclusivas.
            </p>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="flex gap-0"
              aria-label="Suscripción al newsletter"
            >
              <input
                type="email"
                placeholder="Tu email"
                required
                className="flex-1 px-4 py-2.5 text-sm bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-rioja-gold/50 transition-colors"
                style={{ fontFamily: "var(--font-body)" }}
                aria-label="Dirección de email"
              />
              <button
                type="submit"
                className="px-4 py-2.5 flex items-center justify-center transition-colors duration-200"
                style={{ background: "var(--color-gold)" }}
                aria-label="Suscribirse"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </button>
            </form>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="divider-gold opacity-20" />
        <div className="py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p
            className="text-white/30 text-xs"
            style={{ fontFamily: "var(--font-body)" }}
          >
            © {new Date().getFullYear()} La Rioja Turismo. Todos los derechos reservados. Gobierno de La Rioja, Argentina.
          </p>
          <div className="flex items-center gap-1">
            <span className="text-white/20 text-xs" style={{ fontFamily: "var(--font-body)" }}>
              Diseño con
            </span>
            <span className="text-rioja-gold text-xs">♥</span>
            <span className="text-white/20 text-xs" style={{ fontFamily: "var(--font-body)" }}>
              para La Rioja
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
