import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: {
    default: "La Rioja Turismo | Sabor de Vida",
    template: "%s | La Rioja Turismo",
  },
  description:
    "Viñedos infinitos, pueblos con historia, gastronomía única y la calidez de su gente. Descubrí La Rioja, Argentina. Tu próxima gran experiencia te espera.",
  keywords: [
    "La Rioja turismo",
    "viñedos Argentina",
    "enoturismo La Rioja",
    "rutas del vino",
    "gastronomía riojana",
    "turismo Argentina",
    "Valles Calchaquíes",
    "Chilecito",
    "bodegas La Rioja",
  ],
  authors: [{ name: "La Rioja Turismo" }],
  creator: "La Rioja Turismo",
  publisher: "Gobierno de La Rioja",
  metadataBase: new URL("https://lariojaturismo.com"),
  alternates: {
    canonical: "/",
    languages: {
      "es-AR": "/",
    },
  },
  openGraph: {
    type: "website",
    locale: "es_AR",
    url: "https://lariojaturismo.com",
    siteName: "La Rioja Turismo",
    title: "La Rioja, Sabor de Vida | Turismo Oficial",
    description:
      "Viñedos infinitos, gastronomía única y paisajes que enamoran. Descubrí La Rioja Argentina.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "La Rioja - Viñedos y paisajes al atardecer",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "La Rioja, Sabor de Vida",
    description: "Viñedos, gastronomía y paisajes únicos en La Rioja, Argentina.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png" }],
  },
  manifest: "/site.webmanifest",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#1A0F08" },
    { media: "(prefers-color-scheme: light)", color: "#6B1A2A" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es-AR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400;1,500&family=Jost:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "TouristDestination",
              name: "La Rioja",
              description:
                "Provincia argentina con viñedos únicos, gastronomía excepcional y paisajes naturales extraordinarios.",
              url: "https://lariojaturismo.com",
              touristType: [
                "Adventure Tourism",
                "Wine Tourism",
                "Cultural Tourism",
                "Gastronomic Tourism",
              ],
              geo: {
                "@type": "GeoCoordinates",
                latitude: -29.4128,
                longitude: -66.8554,
              },
            }),
          }}
        />
      </head>
      <body>
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[9999] focus:px-4 focus:py-2 focus:text-sm font-semibold"
          style={{ background: "var(--color-gold)", color: "var(--color-dark-earth)" }}
        >
          Ir al contenido principal
        </a>
        <Navbar />
        <main id="main-content">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
