export default function Loading() {
  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center"
      style={{ background: "var(--color-dark-earth)" }}
      aria-label="Cargando..."
      role="status"
    >
      <div className="flex flex-col items-center gap-6">
        <div className="flex flex-col items-center">
          <span
            className="text-2xl font-bold tracking-wider text-white"
            style={{ fontFamily: "var(--font-display)", letterSpacing: "0.06em" }}
          >
            LA RIOJA
          </span>
          <span
            className="text-[9px] tracking-[0.3em] uppercase text-rioja-gold"
            style={{ fontFamily: "var(--font-body)" }}
          >
            TURISMO
          </span>
        </div>
        <div className="w-32 h-px overflow-hidden" style={{ background: "rgba(196,149,42,0.2)" }}>
          <div
            className="h-full"
            style={{
              background: "var(--color-gold)",
              animation: "shimmer 1.5s ease-in-out infinite",
              backgroundSize: "200% 100%",
              backgroundImage: "linear-gradient(90deg, transparent, rgba(196,149,42,1), transparent)",
            }}
          />
        </div>
      </div>
    </div>
  );
}
