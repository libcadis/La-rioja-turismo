import type { Metadata } from "next";
import { HeroSection } from "@/components/sections/HeroSection";
import { ExperiencesSection } from "@/components/sections/ExperiencesSection";
import { WineRoutesSection } from "@/components/sections/WineRoutesSection";
import { TravelPlanSection } from "@/components/sections/TravelPlanSection";
import { InstagramSection } from "@/components/sections/InstagramSection";

export const metadata: Metadata = {
  title: "La Rioja, Sabor de Vida | Turismo Oficial",
  description:
    "Viñedos infinitos, pueblos con historia, gastronomía única y la calidez de su gente. Descubrí La Rioja, Argentina. Tu próxima gran experiencia te espera.",
};

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <ExperiencesSection />
      <WineRoutesSection />
      <TravelPlanSection />
      <InstagramSection />
    </>
  );
}
