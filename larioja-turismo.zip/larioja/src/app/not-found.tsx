import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function NotFound() {
  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{ background: "var(--color-dark-earth)" }}
    >
      <div className="text-center px-6">
        <p
          className="section-label mb-6"
          style={{ fontFamily: "var(--font-body)" }}
        >
          Error 404
        </p>
        <h1
          className="text-white mb-6"
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "clamp(3rem, 8vw, 6rem)",
            fontWeight: 800,
            lineHeight: "1",
          }}
        >
          PÁGINA
          <br />
          <em style={{ fontStyle: "italic", color: "var(--color-gold)" }}>
            NO ENCONTRADA
          </em>
        </h1>
        <p
          className="text-white/50 mb-10 max-w-sm mx-auto leading-relaxed"
          style={{ fontFamily: "var(--font-body)" }}
        >
          Esta página no existe, pero La Rioja tiene mucho más para ofrecerte.
        </p>
        <Link href="/" className="btn-primary">
          <span>Volver al Inicio</span>
          <ArrowRight size={15} />
        </Link>
      </div>
    </div>
  );
}
